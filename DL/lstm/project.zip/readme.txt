For Exact results, please create a virtual envoirnment
To create virtual envoirnment
>>> pip install virtualenvwrapper-win
>>> mkvirtualenv yourEnvName

Then istall requirements using:
>>> pip install -r requirements.txt

After Installation:
use     lstm_and_shap_colab.py
	lstm_and_shap_jupyter.py
	lstm_and_shap_py.py

Remember: .py file will not show the graphs