from common import *

class Node:
    def __init__(self, ID, networksimulator, costs):
        self.myID = ID
        self.ns = networksimulator
        num = self.ns.NUM_NODES        
        self.distanceTable = [[0 for i in range(num)] for j in range(num)]
        self.routes = [0 for i in range(num)]

        # My Code
        ''' Initialize My cost and route'''
        for i in range(num):
            self.distanceTable[self.myID][i] = costs[i]
            if costs[i] != self.ns.INFINITY:
                self.routes[i] = i
        ''' Set Other's cost to Infinity '''
        for i in range(num):
            if i != self.myID:
                for j in range(num):
                    if j == i:
                        self.distanceTable[i][j] = 0
                    else:
                        self.distanceTable[i][j] = self.ns.INFINITY 

        ''' Send own costs (as packet) to other node '''
        for i in range(num):
            if i != ID:
                ''' if Other Node is connected to this one '''
                if costs[i] != self.ns.INFINITY:
                    packet = RTPacket(ID, i, costs)
                    self.ns.tolayer2(packet)
    
    ''' Compute minimum distance from myID to every Other Neighbor (ToNode)'''    
    def bell_man_Ford_distance(self, ToNode):
        '''@param: ToNode: Node for which current node wants to compute distance
        '''
        myID = self.myID
        ''' compute inner equation '''
        innerDistances = {} # To hold distances against first Node in a path
        for i in range(self.ns.NUM_NODES):
            if i != self.myID:
                distance = self.distanceTable[myID][i]+self.distanceTable[i][ToNode]
                innerDistances[i] = distance
        
        ''' return minimum of the distances and its respective firstNode '''
        firstNode = min(innerDistances, key=innerDistances.get)
        minDistance = innerDistances[firstNode]
        return firstNode, minDistance

    def recvUpdate(self, pkt):
        self.distanceTable[pkt.sourceid] = pkt.mincosts
        
        # My Code
        ''' Update Distance for neighbors '''
        updateFlag = False # Trace, if any update has been made
        for i in range(self.ns.NUM_NODES):
            if i != self.myID:
                ''' Dmyid(I) = min{c(myid,I) + DI(I), } '''
                firstNode, minDistance = self.bell_man_Ford_distance(i)
                ''' Update Distance Table & route Node if distance is updated '''
                if self.distanceTable[self.myID][i] != minDistance: # >
                    updateFlag = True
                    self.distanceTable[self.myID][i] = minDistance
                    self.routes[i] = firstNode
        ''' Send my cost to neighbors if any update is made '''
        if updateFlag:
            for i in range(self.ns.NUM_NODES):
                ''' Send own costs (as packet) to other node '''
                if i != self.myID:
                    ''' if Other Node is connected to this one '''
                    if self.distanceTable[self.myID][i] != self.ns.INFINITY:
                        packet = RTPacket(self.myID, i, self.distanceTable[self.myID])
                        self.ns.tolayer2(packet)     
         

    
    def printdt(self):
        print("   D"+str(self.myID)+" |  ", end="")
        for i in range(self.ns.NUM_NODES):
            print("{:3d}   ".format(i), end="")
        print()
        print("  ----|-", end="")
        for i in range(self.ns.NUM_NODES):            
            print("------", end="")
        print()    
        for i in range(self.ns.NUM_NODES):
            print("     {}|  ".format(i), end="" )
            
            for j in range(self.ns.NUM_NODES):
                print("{:3d}   ".format(self.distanceTable[i][j]), end="" )
            print()            
        print()
        
