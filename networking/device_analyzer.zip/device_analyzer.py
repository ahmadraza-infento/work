import time
import pandas as pd
from scapy.all import *

# Stage 1
class Assignment:
    def isResponsive(self, ipaddr, retry=1, timeout=3):
        try:
            resp = sr1(IP(dst=ipaddr)/ICMP(), retry=retry, timeout=timeout)

            if resp:
                return True
            else:
                return False
        except Exception as e:
            print(f'[EXCEPTION]@isResponsive --> {e}')
            '''-1 means exception occured'''
            return -1
    
    def isIncremental(self, ids):
        flag = True
        for i, id in enumerate(ids):
            if i > 0:
                if ids[i-1] >= ids[i]:
                    flag = False
                    break

        return flag

    def get_deployed_ip_id_counter_ip(self, ipaddress="", requestsToSend=5):
        try:
            ip_ids = []
            for i in range(requestsToSend):
                resp = sr1(IP(dst=ipaddress)/ICMP(), timeout=3)
                if resp:
                    ip_ids.append(resp.id)
            if len(ip_ids) == 0:
                return None
            elif sum([True if ip == 0 else False for ip in ip_ids ]) == len(ip_ids):
                return 0
            elif self.isIncremental(ip_ids):
                return 1
            else:
                return 2
        except Exception as e:
            print(f'[EXCEPTION]@counter_ip --> {e}')
            '''-1 means exception occured'''
            return -1
    
    '''Is port 80 available on device'''
    def isPort80(self, ipaddr):
        try:
            SYN = IP(dst=ipaddr)/TCP(dport=80, flags='S')
            res = sr1(SYN, timeout=3)
            return True if res else False
        except Exception as e:
            print(f'[EXCEPTION]@isPort80 --> {e}')
            '''-1 means exception occured'''
            return -1
    
    
    def get_deployed_ip_id_counter_tcp(self, ipaddress="", requestsToSend=5):
        try:
            ip_ids = []
            for i in range(requestsToSend):
                resp = sr1(IP(dst=ipaddress)/TCP(dport=80, flags='S'), timeout=3)
                if resp:
                    ip_ids.append(resp.id)
            if len(ip_ids) == 0:
                return None
            elif sum([True if ip == 0 else False for ip in ip_ids ]) == len(ip_ids):
                return 0
            elif self.isIncremental(ip_ids):
                return 1
            else:
                return 2
        except Exception as e:
            print(f'[EXCEPTION]@ip_counter_tcp --> {e}')
            '''-1 means exception occured'''
            return -1
    
    '''SYN Cookiese are deployed on device or not'''    
    def synCookiesDeployed(self, ipaddr):
        try:
            resLen = []
            target_port = 80
            start_time = time.time()
            while time.time() - start_time <= 60:
                ans, unans = sr(IP(dst=ipaddr)/TCP(dport=target_port, flags='S'), timeout=3)
                resLen.append(len(ans)>1)
            tmp = sum(resLen)
            if tmp == 0:
                return True
            else:
                return False
        except  Exception as e:
            print(f'[EXCEPTION]@synCookiesDepl --> {e}')
            '''-1 means exception occured'''
            return -1
    
    def findOS(self, ipaddr):
        try:
            window_size_map = {5840:'Linux', 32120:'Linux', 16384:'Windows', 65535:'Windows', 
                  8192:"Windows"}
            ttl_value_map = {64:'Linux', 64:'Linux', 128:'Windows', 128:'Windows', 
                          128:"Windows"}
            ttl_win_map = {'645840':'Linux', '6432120':'Linux', '12816384':'Windows', '12865535':'Windows', 
                          '1288192':"Windows"}

            resp = sr1(IP(dst=ipaddr)/ICMP(), timeout=3)
            ttl_val = None
            try:ttl_val = resp.ttl
            except:pass

            resp = sr1(IP(dst=ipaddr)/TCP(flags='S'), timeout=3)
            win_size = None
            try:win_size = resp.window
            except:pass
            if ttl_val in ttl_value_map.keys():
                if win_size:
                    if f'{ttl_val}{win_size}' in ttl_win_map.keys():
                        return ttl_win_map[f'{ttl_val}{win_size}']
                    else:
                        return None
                else:
                    return ttl_value_map[ttl_val]
            elif win_size in window_size_map.keys():
                return window_size_map[win_size]
            else:
                return None
        except  Exception as e:
            print(f'[EXCEPTION]@findOS --> {e}')
            '''-1 means exception occured'''
            return -1

if __name__ == '__main__':
    ''' Stage 2 '''
    selected_file = './shodan-export_IPcamera_foscam/shodan_data.xlsx'
    print('[INFO] Selected File is: ', selected_file)
    df = pd.read_excel(selected_file)
    print('[INFO] Total IP Addresses Found: ', len(df['IP']))
    ipaddress = list(df['IP'])
    # Unique ip_address
    unique_ipaddress = list(set(ipaddress))
    print('[INFO] Total Unique IP Addresses Found: ', len(unique_ipaddress))
    results = {'responsive' : [], 'IDCounterIP':[], 'IDCounterTCP':[], 'port80':[], 'SYNCookies':[], 'os':[],  'failed':[]}
    obj = Assignment()
    count = len(unique_ipaddress)
    for i, ipaddr in enumerate(unique_ipaddress):
        try:
            print(f'[{i}/{count}]')
            results['responsive'].append(obj.isResponsive(ipaddr))
            results['IDCounterIP'].append(obj.get_deployed_ip_id_counter_ip(ipaddr))
            flag = obj.isPort80(ipaddr)
            results['port80'].append(flag)
            if flag:
                '''Perform next tasks in sequence'''
                results['IDCounterTCP'].append(obj.get_deployed_ip_id_counter_tcp(ipaddr))
                results['SYNCookies'].append(obj.synCookiesDeployed(ipaddr))
                results['os'].append(obj.findOS(ipaddr))
            else:
                '''Proceed to last task'''
                results['os'].append(obj.findOS(ipaddr))
        except Exception as e:
            print(f'[Exception] {e}')
            results['failed'].append(ipaddr)
    
    ''' Stage 3 '''
    # Number of responsive devices
    responsive_devices = len([item for item in results['responsive'] if item is True]) 
    print(f'[INFO] Responsive Devices: {responsive_devices}/', len(results['responsive']))

    # Percentage of devices with zero/incremental/random IP-ID IP
    items_count = len(results['IDCounterIP'])
    zero_percentage = round(len([item for item in results['IDCounterIP'] if item == 0]) / items_count, 2)*100
    print('[INFO] Percentage of zero IP-ID-counter (IP) : ', zero_percentage)
    incre_percentage = round(len([item for item in results['IDCounterIP'] if item == 1]) / items_count, 2)*100
    print('[INFO] Percentage of incremental IP-ID-counter (IP) : ', incre_percentage)
    random_percentage = round(len([item for item in results['IDCounterIP'] if item == 2]) / items_count, 2)*100
    print('[INFO] Percentage of random IP-ID-counter (IP) : ', random_percentage)

    # Devices with port 80 opened
    items_count = len(results['port80'])# len([item for item in results['port80'] if item is not None or item != -1])
    port80Percentage = round(len([item for item in results['port80'] if item]) / items_count, 2 ) * 100
    print('[INFO] Percentage of Devices with port 80 open: ', port80Percentage)

    # Percentage of devices with zero/incremental/random IP-ID TCP
    items_count = len(results['IDCounterTCP'])# len([item for item in results['IDCounterTCP'] if item is not None or item != -1])
    zero_percentage = round(len([item for item in results['IDCounterTCP'] if item == 0]) / items_count, 2)*100
    print('[INFO] Percentage of zero IP-ID (TCP) : ', zero_percentage)
    incre_percentage = round(len([item for item in results['IDCounterTCP'] if item == 1]) / items_count, 2)*100
    print('[INFO] Percentage of incremental IP-ID (TCP) : ', incre_percentage)
    random_percentage = round(len([item for item in results['IDCounterTCP'] if item == 2]) / items_count, 2)*100
    print('[INFO] Percentage of random IP-ID (TCP) : ', random_percentage)

    # Percentage of Devices that deployes SYN cookies 
    items_count = len(results['SYNCookies'])# len([item for item in results['SYNCookies'] if item is not None or item != -1])
    SYNCookiesPercentage = (len([item for item in results['SYNCookies'] if item]) / items_count ) * 100
    print('[INFO] Percentage of Devices that deploys SYN cookies : ', SYNCookiesPercentage)

    # Percentage of Devices with linux OS
    items_count = len(results['os'])# len([item for item in results['os'] if item is not None or item != -1])
    linuxPercentage = (len([item for item in results['os'] if item == 'Linux']) / items_count ) * 100
    print('[INFO] Percentage of Devices with linux OS: ', linuxPercentage)

    # Percentage of Devices with Windows OS
    items_count = len(results['os'])# len([item for item in results['os'] if item is not None or item != -1])
    winPercentage = (round(len([item for item in results['os'] if item == 'Windows']) / items_count, 2) ) * 100
    print('[INFO] Percentage of Devices with Windows OS: ', winPercentage)