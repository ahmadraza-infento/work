from threading import Thread
from scapy.all import Ether, TCP, sniff
from scapy.layers.http import HTTPRequest

class TrafficMonitor(Thread):
    def __init__(self, print_packet=False):
        '''
            @param: print_packet -> print traced packet if set true
        '''
        super().__init__()

        self.HTTPS          = 443
        self._PRINT_PACKET  = print_packet
        self._packets       = {'https':[], 'http':[]}

    def get_http(self):
        ''' return oldest traced http request, None if no request is traced '''
        
        return self._packets['http'].pop(0) if len(self._packets['http']) > 0 else None

    def get_https(self):
        ''' return oldest traced http request, None if no request is traced '''
        
        return self._packets['https'].pop(0) if len(self._packets['https']) > 0 else None

    def _is_outgoing(self, packet):
        return packet[Ether].src == Ether().src

    def _is_http(self, packet):
        return packet.haslayer(HTTPRequest)

    def _is_https(self, packet):
        if packet.haslayer(TCP):
            if packet[TCP].dport == self.HTTPS:
                return True
            
            else:
                return False
        else:
            return False
    
    def _on_packet_traced(self, packet):
        ''' callback function, when a packet is traced '''
        
        if self._is_outgoing(packet):
            
            if self._is_http(packet):
                if self._PRINT_PACKET:
                    packet.show()
                
                else:
                    self._packets['http'].append(packet)
     
            elif self._is_https(packet):
                
                if self._PRINT_PACKET:
                    packet.show()
                
                else:
                    self._packets['https'].append(packet)
            
            else:
                pass
        
        else:
            pass

    def _monitor_traffic(self):
        ''' monitor outgoing traffic in a system '''
        sniff(prn=self._on_packet_traced)

    def run(self):
        self._monitor_traffic()



if __name__ == '__main__':
    trafficMonitor = TrafficMonitor(print_packet=False)
    trafficMonitor.setDaemon(True)
    trafficMonitor.start()

    while True:
        inp = input('your input(h->http, hs->https, e->exit)? >>>')
        if inp == 'h':
            packet = trafficMonitor.get_http()
            if packet:
                packet.show()
            
            else:
                print('no http packet found')

        elif inp == 'hs':
            packet = trafficMonitor.get_https()
            if packet:
                print('https packet found')
                packet.show()
            
            else:
                print('no https packet found')

        else:
            break
